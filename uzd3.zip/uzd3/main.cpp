#include <iostream>
#include <fstream>
#include <iomanip>
#include <string>

using namespace std;

int main() {
    int pasirinkimas;
    string failas, failas2;
    cout << fixed << setprecision(2);


    while (pasirinkimas != 0) {
        cout << "1. Apskaiciuoti bilietu pardavimus" << endl;
        cout << "2. Atnaujinti darbuotoju atlyginimus" << endl;
        cout << "0. Baigti programa" << endl;
        cin >> pasirinkimas;

        if (pasirinkimas == 1) {
            ifstream in;
            ofstream out;
            in.open("bilietai.txt");
            out.open("bilietai2.txt");

            if (!in) {
                cout << "Nepavyko atidaryti failo" << endl;
            } else {
                double kaina, suma = 0;
                int kiekis, visibilietai = 0;
                string eilute;
                while (in >> kaina >> kiekis) {
                    suma = suma + (kaina * kiekis);
                    visibilietai = visibilietai + kiekis;
                }
                out << fixed << setprecision(2);
                cout << "Parduota bilietu: " << visibilietai << endl;
                cout << "Bendra suma: " << suma << " EUR" << endl;
                out << "Parduota bilietu: " << visibilietai << endl;
                out << "Bendra suma: " << suma << " EUR" << endl;
            }
            in.close();
            out.close();
        }

        else if (pasirinkimas == 2) {
            ifstream in;
            ofstream out;
            in.open("atlyg.txt");
            out.open("atlyg2.txt");

            if (!in) {
                cout << "Nepavyko atidaryti failo" << endl;
            } else {
                string pavarde, vardas;
                double atlyginimas, procentas, naujas;
                while (in >> pavarde >> vardas >> atlyginimas >> procentas) {
                    out << fixed << setprecision(2);
                    naujas = atlyginimas + (atlyginimas * procentas / 100);
                    cout << pavarde << " " << vardas << " " << naujas << endl;
                    out << pavarde << " " << vardas << " " << naujas << endl;
                }
            }
            in.close();
            out.close();
        }

        else if (pasirinkimas == 0) {
            cout << "Programa baigia darba" << endl;
            break;
        }

        else {
            cout << "Tokio pasirinkimo nera" << endl;
        }
    }

    return 0;
}
